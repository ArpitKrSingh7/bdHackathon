Internet Ads Big Data Hackathon source bundle

Contents: source scripts, executed notebook, final PDF report, dependency versions, progress/handoff notes, generated analysis outputs, and the local MLflow SQLite database/artifacts. The original raw data is not bundled; download it from:
https://archive.ics.uci.edu/static/public/51/internet+advertisements.zip

Extract the archive. Put the UCI source files in data/raw/ (ad.data, ad.names, ad.DOCUMENTATION, internet-advertisements.zip). Install the packages in requirements.txt, then run from the bdHackathon directory:

  python3 preprocess_dataset.py
  python3 association_mining.py
  python3 classification_clustering.py
  python3 pyspark_benchmark.py
  python3 report_figures.py
  python3 log_experiments.py
  python3 build_notebook.py
  python3 build_report.py
  python3 package_sources.py

The captured benchmark completed both PySpark workloads in local[2]. Spark was slower than the matched local tasks on this 3,279-row dataset; startup and data-conversion/collection costs are recorded separately. If a later environment blocks the Java gateway socket, the benchmark records that status without inventing task timings.

Internet Ads has no timestamps, sessions, or natural event order. The synthetic GSP sequence demonstration is not a dataset finding and does not fulfill dataset-level sequential mining; ordered event data or an instructor-approved interpretation would be needed for that requirement.
